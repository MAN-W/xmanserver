function showPage(pageId) {
    document.querySelectorAll('.hero, .login-container, .content-container').forEach(section => {
        section.classList.add('hidden');
    });
    document.getElementById(pageId).classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
    showPage('home');

    const loginForm = document.getElementById('loginForm');
    const errorMessage = document.getElementById('errorMessage');

    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        if (username === 'XMAN' && password === 'XMAN3/24') {
            showPage('content');
        } else {
            errorMessage.textContent = 'Invalid username or password. Please try again.';
        }
    });
});
